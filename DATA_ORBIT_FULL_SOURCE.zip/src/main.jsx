import Valley from "./Valley.jsx";
import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUpRight, ArrowRight, Menu, X, Database,
  BrainCircuit, ChartNoAxesCombined, Code2, Workflow,
  ShieldCheck, Sparkles, CheckCircle2, Mail, Globe2,
  Layers3
} from "lucide-react";
import PremiumHero from "./PremiumHero.jsx";
import "./style.css";

const services = [
  {
    number: "01",
    icon: Database,
    title: "Data Engineering",
    text: "Turn scattered data into structured, reliable foundations for better decisions.",
    tags: ["Data pipelines", "SQL", "Cloud data"]
  },
  {
    number: "02",
    icon: BrainCircuit,
    title: "Artificial Intelligence",
    text: "Build practical AI experiences that help teams work smarter and faster.",
    tags: ["Machine learning", "GenAI", "Automation"]
  },
  {
    number: "03",
    icon: ChartNoAxesCombined,
    title: "Analytics & BI",
    text: "Transform complex metrics into clear dashboards, insights and business stories.",
    tags: ["Power BI", "Dashboards", "Forecasting"]
  },
  {
    number: "04",
    icon: Code2,
    title: "Digital Engineering",
    text: "Create modern web experiences with thoughtful design and dependable technology.",
    tags: ["Web applications", "APIs", "UX engineering"]
  },
  {
    number: "05",
    icon: Workflow,
    title: "Intelligent Automation",
    text: "Streamline repetitive workflows and connect tools across your business.",
    tags: ["Workflows", "Integrations", "Process design"]
  },
  {
    number: "06",
    icon: ShieldCheck,
    title: "Data Strategy",
    text: "Build a clearer roadmap for data quality, responsible AI and measurable outcomes.",
    tags: ["Data quality", "Governance", "Strategy"]
  }
];

const projects = [
  {
    no: "01",
    category: "BUSINESS INTELLIGENCE",
    title: "Business Performance Intelligence",
    description: "A dashboard concept for tracking revenue, sales trends, customer behaviour and business KPIs.",
    type: "ANALYTICS",
    visual: "visual-dashboard"
  },
  {
    no: "02",
    category: "MACHINE LEARNING",
    title: "Predictive Insight Engine",
    description: "A machine-learning concept that turns historical patterns into useful predictive signals.",
    type: "PREDICTIVE AI",
    visual: "visual-predict"
  },
  {
    no: "03",
    category: "GENERATIVE AI",
    title: "Knowledge Intelligence System",
    description: "A modern AI experience concept for exploring knowledge and retrieving contextual answers.",
    type: "GENAI",
    visual: "visual-network"
  }
];

function Navigation() {
  const [open, setOpen] = useState(false);
  const links = [
    ["Services", "#services"],
    ["Work", "#work"],
    ["About", "#about"]
  ];

  return (
    <header className="site-header">
      <a href="#home" className="brand" aria-label="Data Orbit Technologies home">
        <span className="brand-mark"><span /><span /><span /></span>
        <span className="brand-name">DATA ORBIT<span>TECHNOLOGIES</span></span>
      </a>

      <button
        className="mobile-toggle"
        aria-label={open ? "Close navigation" : "Open navigation"}
        aria-expanded={open}
        onClick={() => setOpen(!open)}
      >
        {open ? <X size={21} /> : <Menu size={21} />}
      </button>

      <nav className={open ? "nav-links nav-open" : "nav-links"}>
        {links.map(([label, href]) => (
          <a key={label} href={href} onClick={() => setOpen(false)}>{label}</a>
        ))}
        <a className="nav-contact" href="#contact" onClick={() => setOpen(false)}>
          Let's talk <ArrowUpRight size={15} />
        </a>
      </nav>
    </header>
  );
}

function ProjectVisual({ type }) {
  if (type === "visual-dashboard") {
    return (
      <div className="mock-dashboard">
        <div className="mock-top"><span /><span /><span /><i>OVERVIEW / 2026</i></div>
        <div className="mock-metrics">
          <div><small>REVENUE</small><b>↑ Growth</b></div>
          <div><small>ORDERS</small><b>Activity</b></div>
          <div><small>CUSTOMERS</small><b>Insights</b></div>
        </div>
        <div className="chart-area">
          <div className="chart-y"><i /><i /><i /><i /></div>
          <svg viewBox="0 0 360 105" preserveAspectRatio="none" aria-label="Illustrative analytics chart">
            <defs>
              <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#68efa4" stopOpacity=".32" />
                <stop offset="100%" stopColor="#68efa4" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d="M0 83 C30 76 37 86 64 63 S104 76 134 49 S177 63 205 37 S246 54 274 26 S322 42 360 8 L360 105 L0 105Z" fill="url(#chartFill)" />
            <path d="M0 83 C30 76 37 86 64 63 S104 76 134 49 S177 63 205 37 S246 54 274 26 S322 42 360 8" fill="none" stroke="#75f2ae" strokeWidth="2" />
          </svg>
        </div>
        <div className="chart-bottom"><span>WEEK 01</span><span>WEEK 02</span><span>WEEK 03</span><span>WEEK 04</span></div>
      </div>
    );
  }

  if (type === "visual-predict") {
    return (
      <div className="predict-visual">
        <div className="predict-orbit orbit-one" />
        <div className="predict-orbit orbit-two" />
        <div className="predict-core"><BrainCircuit size={37} strokeWidth={1.2} /></div>
        <span className="predict-node node-one" />
        <span className="predict-node node-two" />
        <span className="predict-node node-three" />
        <span className="predict-label label-one">PATTERNS</span>
        <span className="predict-label label-two">PREDICTIONS</span>
      </div>
    );
  }

  return (
    <div className="network-visual">
      <div className="network-grid" />
      <div className="network-center"><Sparkles size={30} /></div>
      {Array.from({ length: 12 }, (_, i) => (
        <span key={i} className={`network-point point-${i + 1}`} />
      ))}
      <div className="network-tag">CONTEXT · REASONING · INSIGHT</div>
    </div>
  );
}

function ContactSection() {
  const [form, setForm] = useState({ name: "", email: "", service: "Data & Analytics", message: "" });

  function submitForm(event) {
    event.preventDefault();
    const subject = encodeURIComponent(`Project enquiry — ${form.service}`);
    const body = encodeURIComponent(
      `Name: ${form.name}\nEmail: ${form.email}\nService: ${form.service}\n\nProject details:\n${form.message}`
    );
    window.location.href = `mailto:hello@dataorbittechnologies.com?subject=${subject}&body=${body}`;
  }

  return (
    <section className="contact-section section-pad" id="contact">
      <div className="contact-glow" />
      <div className="contact-layout">
        <div className="contact-copy">
          <div className="eyebrow"><span /> LET'S BUILD SOMETHING MEANINGFUL</div>
          <h2>Have a challenge?<br /><em>Let's solve it.</em></h2>
          <p>Tell us what you're working on. Let's explore how data, AI and engineering can move your idea forward.</p>
          <a className="contact-email" href="mailto:hello@dataorbittechnologies.com">
            <Mail size={17} /> hello@dataorbittechnologies.com <ArrowUpRight size={15} />
          </a>
          <div className="contact-note"><span /> OPEN TO NEW PROJECT ENQUIRIES</div>
        </div>

        <form className="contact-form" onSubmit={submitForm}>
          <div className="form-heading"><span>PROJECT ENQUIRY</span><span>01 — 04</span></div>
          <label>
            Your name
            <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="How should we address you?" />
          </label>
          <label>
            Work email
            <input required type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="you@company.com" />
          </label>
          <label>
            What do you need?
            <select value={form.service} onChange={e => setForm({ ...form, service: e.target.value })}>
              <option>Data & Analytics</option>
              <option>Artificial Intelligence</option>
              <option>Web Development</option>
              <option>Automation</option>
              <option>Data Strategy</option>
              <option>Something else</option>
            </select>
          </label>
          <label>
            Tell us about your project
            <textarea required rows="3" value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} placeholder="A little context helps us get started..." />
          </label>
          <button className="submit-button" type="submit">Send project enquiry <ArrowUpRight size={17} /></button>
          <p className="form-footnote">Your email app will open with your enquiry prepared for sending.</p>
        </form>
      </div>
    </section>
  );
}

function App() {
  return (
    <>
      <Navigation />
      <main>
        <PremiumHero />
      <Valley />

        <section className="signal-strip" aria-label="Our capabilities">
          <span>BUILT AROUND YOUR AMBITION</span>
          <div><Database size={15} /> DATA</div>
          <i />
          <div><BrainCircuit size={15} /> INTELLIGENCE</div>
          <i />
          <div><Globe2 size={15} /> ENGINEERING</div>
          <i />
          <div><Layers3 size={15} /> DESIGN</div>
        </section>

        <section className="services-section section-pad" id="services">
          <div className="section-heading">
            <div>
              <div className="eyebrow"><span /> WHAT WE DO</div>
              <h2>Technology with<br /><em>a clear purpose.</em></h2>
            </div>
            <p>From data foundations to intelligent digital products, we connect strategy, technology and thoughtful execution.</p>
          </div>

          <div className="services-grid">
            {services.map(({ number, icon: Icon, title, text, tags }) => (
              <article className="service-card" key={number}>
                <div className="service-top"><span>{number} / 06</span><Icon size={22} strokeWidth={1.4} /></div>
                <h3>{title}</h3>
                <p>{text}</p>
                <div className="service-tags">{tags.map(tag => <span key={tag}>{tag}</span>)}</div>
                <a href="#contact" aria-label={`Discuss ${title}`} className="card-arrow"><ArrowUpRight size={18} /></a>
              </article>
            ))}
          </div>
        </section>

        <section className="work-section section-pad" id="work">
          <div className="section-heading work-heading">
            <div>
              <div className="eyebrow"><span /> SELECTED CONCEPTS</div>
              <h2>Ideas, made <em>tangible.</em></h2>
            </div>
            <p>Explorations in analytics, predictive intelligence and AI-powered experiences.</p>
          </div>

          <div className="projects-grid">
            {projects.map(project => (
              <article className="project-card" key={project.no}>
                <div className="project-art"><ProjectVisual type={project.visual} /><span className="project-index">{project.no}</span></div>
                <div className="project-details">
                  <div className="project-category">{project.category}</div>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <div className="project-bottom"><span>{project.type}</span><a href="#contact" aria-label={`Enquire about ${project.title}`}><ArrowUpRight size={17} /></a></div>
                </div>
              </article>
            ))}
          </div>
          <p className="concept-note">Illustrative project concepts · Not client case studies or claimed business results.</p>
        </section>

        <section className="about-section section-pad" id="about">
          <div className="about-visual">
            <div className="about-rings"><div className="about-ring ring-a" /><div className="about-ring ring-b" /><div className="about-ring ring-c" /><div className="about-core"><span>DO</span></div></div>
            <div className="about-coordinate">17° 23' N<br />78° 29' E</div>
            <div className="about-visual-label">A DIFFERENT VIEW OF DATA</div>
          </div>
          <div className="about-copy">
            <div className="eyebrow"><span /> OUR APPROACH</div>
            <h2>Clarity in complexity.<br /><em>Purpose in every pixel.</em></h2>
            <p>Data Orbit Technologies brings together data, AI and digital engineering to help turn complex challenges into clear, useful experiences.</p>
            <p>Our approach is grounded in understanding the problem first, choosing the right technology, and designing for the people who will use the result.</p>
            <div className="about-points">
              <div><CheckCircle2 size={17} /><span><b>Problem-first thinking</b><small>Start with the outcome, not the hype.</small></span></div>
              <div><CheckCircle2 size={17} /><span><b>Purposeful engineering</b><small>Build for usability and maintainability.</small></span></div>
              <div><CheckCircle2 size={17} /><span><b>Insight-led decisions</b><small>Make complexity easier to understand.</small></span></div>
            </div>
            <a href="#contact" className="text-link">Explore a collaboration <ArrowRight size={16} /></a>
          </div>
        </section>

        <ContactSection />
      </main>

      <footer className="site-footer">
        <a href="#home" className="brand footer-brand">
          <span className="brand-mark"><span /><span /><span /></span>
          <span className="brand-name">DATA ORBIT<span>TECHNOLOGIES</span></span>
        </a>
        <p>Turning data into intelligence.</p>
        <a href="#home" className="back-top">BACK TO TOP ↑</a>
        <small>© {new Date().getFullYear()} Data Orbit Technologies. All rights reserved.</small>
      </footer>
    </>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode><App /></React.StrictMode>
);


